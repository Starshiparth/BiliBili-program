a = 1
a = 2
print(a)
'''
强制转换：
a代表需要转换的数据
转换字符串：str(a)
转换整型：int(a)
转换字典：dist(a)
转换列表：list(a)
以此类推
'''
b = 180
c = str(b)
print(c)
