from requests import get

header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54'
}  # 伪装成浏览器需要添加User-Agent
a = get('https://shequ.codemao.cn', headers=header) # 发送get请求，必须要填入请求头
print(a) # 出来的是响应码，200为正常
print(a.text) # 出来的是源代码
with open('源代码.txt', 'a+', encoding='utf-8') as b: # with as 代码块的开端
    b.write(a.text) # 写入文件
