import random  # 导入随机库


def chou(people_list : list):
    print('本次参与“今天谁洗碗”活动的人员有：')
    for i in range(len(people_list) - 1):  # 开始循环播报参加人员名称
        print(people_list[i])
    print(people_list[-1])  # 通过倒序索引播报最后一人
    print('-' * 20 + '正在选取……' + '-' * 20)
    people = random.choice(people_list)  # 进行抽取，调用random的choice函数，从people_list这个列表中选择一项，将其放入变量people中
    print(f'本轮被抽取的是：{people}。恭喜！')  # 播报被抽取到的人
    return people


def chuliyiyi(chou_return_people : str, people_list : list):
    true_or_false = bool(input(f'{chou_return_people}，是否有异议？（有异议请随便填一个字符，没有请直接换行）'))  # 运用到了布尔值
    if true_or_false:  # 如果为True（有字符），执行后面的指令
        print('开始二次抽取，本次将为最终结果。')
        chou(people_list)
    else:
        print(f'已确定最终人选：{chou_return_people}。')


with open('参与人员.txt', 'r', encoding='utf-8') as read:  # 从参与人员.txt中读取参与抽洗碗人的名单，with as 代码块后面详细讲
    People = read.read()  # 切记，存入一个变量中。
people_List = People.split(',')  # 将字符串以“,”为分割记号分割字符串，存入people_List
return_people = chou(people_List)
chuliyiyi(return_people, people_List)
