import turtle # 导入turtle库

def draw(x, y, a): # 定义函数draw
    turtle.penup() # 抬起画笔，以便前往路中不留下痕迹
    turtle.goto(x, y) # 前往指定坐标
    turtle.pendown() # 落笔
    for i in range(a):
        turtle.circle(100, 360, 3) # turtle的画圆函数，第一个指半径，第二个指角度，第三个指内切次数（如果没有太大的需求，只需要第一个参数就行了）
        turtle.left(360 / a)


draw(y=100, a=5, x=80)