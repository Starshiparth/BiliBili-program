from turtle import *
from time import sleep
from sys import exit  # 导入3个本次所需要的库的部分内容

hideturtle()
time = int(textinput('询问窗口', '你需要倒计时多少秒？'))  # 询问需要倒计时多少秒
for i in range(1, time, 1):  # for循环
    write(time, align='center', font=('kaiti', 100, 'normal'))  # 打印当前秒数
    sleep(1)  # 等待1秒
    clear()  # 清屏
    time -= 1  # 计时器-1
write('倒计时已结束！', align='center', font=('kaiti', 80, 'normal'))  # 打印“倒计时已结束！”
sleep(5)  # 等待5秒，让用户不会措手不及
exit()  # 终止解释器所有任务
