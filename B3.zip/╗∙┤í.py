print("Hello world!") # print是打印，输出的意思，用这个函数输出（打印在交互式编程环境中）Hello world!

